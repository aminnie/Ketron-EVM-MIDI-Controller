import supervisor

# Turn off the status bar if you haven’t already
supervisor.status_bar.display = False

# Then blank the entire display
supervisor.runtime.display.root_group = None